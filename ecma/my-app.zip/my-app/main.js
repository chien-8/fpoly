import Navigo from "navigo";
import Detailproduct from "./src/pages/detail-product";
import HomePage from './src/pages/home';
import ProductPage from "./src/pages/product";
import ManageProduct  from "./src/pages/manage-product";
import AddNewProduct from "./src/pages/add-new-product";
import UpdateProduct from "./src/pages/update-product";
import deleteProduct from "./src/pages/remove";

// document.querySelector("#app").innerHTML="hello world"
const router = new Navigo("/",{linksSelector:"a"});
const print= async (content,id)=>{
  document.querySelector("#app").innerHTML=await content.render(id);
  if(content.afterRender){
    content.afterRender(id);
  }
}

router.on({
  "/": () => {
    // document.querySelector("#app").innerHTML="home page";
    // console.log("Home Page");
    print(HomePage);
  },
  "/products": () =>{
    // document.querySelector("#app").innerHTML="products page";
    // console.log("Products Page");
    print(ProductPage);
  },
  "/products/:id": (value)=>{
    print(Detailproduct,value.data.id);
  },
  "/about": ()=> {
    // document.querySelector("#app").innerHTML="about page";
    // console.log("About Page");
    print("about page");
  },
  "/admin/manage-product": ()=>{
    print(ManageProduct );
  },
  "/admin/products/add":()=>{
    print(AddNewProduct)
  },
  "/admin/products/:id/update":(value)=>{
    print(UpdateProduct,value.data.id)
  },
  "/admin/products/:id/remove":(value)=>{
    print(deleteProduct,value.data.id)
  }

});

router.resolve();


