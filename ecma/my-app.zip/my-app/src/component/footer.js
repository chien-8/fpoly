import stypes from "../stype/footer.css" assert {type:'css'}
document.adoptedStyleSheets[stypes]
const footer={
    render(){
        return /*html*/`
    
        <img src="../image/logo.png" alt="">
        <ul>
            <li><a href="">Home</a></li>
            <li><a href="">Products</a></li>
            <li><a href="">About Us</a></li>
            <li><a href="">Contact Us</a></li>
        </ul>
    
        `
    }
}
export default footer;