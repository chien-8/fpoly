import stypes from "../stype/header.css" assert {type:'css'}
document.adoptedStyleSheets[stypes]
const Header = {
    render() {
        return /* html */`
        <div class="logo">
            <img src="../image/logo.png">
         </div>
        <nav>
            <ul>
                <li><a href="/">HomePage</a></li>
                <li><a href="/products">Products</a></li>
                <li><a href="/about">About</a></li>
                <li><a href="/admin/manage-product">Admin</a></li>
                <li><a href="">Blog</a></li>
            </ul>
        </nav>
        <div class="account">
            <a href="">
                <button class="sign-in">Sign In</button>
            </a>
            <a href="">
                <button class="sign-up">Sign Up</button>
            </a>
        </div>
        `
    }
}
export default Header;