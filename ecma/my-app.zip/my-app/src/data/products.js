const productList = [
    {
        id:1,
        name:"Product 1",
        price:400,
        image: "https://picsum.photos/200/300"
    },
    {
        id:2,
        name:"Product 2",
        price:200,
        image: "https://picsum.photos/200/300"
    }
]

export default productList;