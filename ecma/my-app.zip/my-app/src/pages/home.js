import { getAll } from "../api/products";
import footer from "../component/footer";
import Header from "../component/header";
import stypes from "../stype/stype.css" assert {type: 'css'};
document.adoptedStyleSheets[stypes];
const HomePage ={
    async render(){
        const productList=(await getAll()).data;
        return /* html */ `
            <div class="container">
                <header>
                    ${Header.render()} 
                </header>
                <section class="banner">
                    <div class="banner__info">
                        <p>Quality Food</p>
                        <h2>Fastest</h2>
                        <h2>
                            <span>Delivery</span>"&"
                        </h2>
                        <h2>
                            "Easy"<span>Pickup</span>
                        </h2>
                        <p>"Best cooks and best delivery guys all at your service. Hot tasty food will reach you in 60 minutes.
                        "</p>
                    </div>
                    <div class="banner__img">
                         <img src="" alt>
                    </div>
                </section>
                <section class="popular">
                    <h2>Our Popular Dishes</h2>
                    <p>Lorem ipsum dolor sit amet, consectetuipisicing elit, sed do eiusmod tempor incididunt ut labore et
                     dolore magna aliqut enim ad minim </p>

                    <div class="filter">
                        <select name="" id="filter-select">
                            <option value="" hidden>Lọc giá</option>
                            <option value="all">Tất cả</option>
                            <option value="under30">Dưới 30 $</option>
                            <option value="over30">Trên 30 $</option>
                        </select>
                     </div>


                    <div class="popular-list">
                        ${productList.map((item)=>{
                            return /*html*/`
                                <div class="popular__item">
                                    <div class="item">
                                        <img src="${item.image}">
                                        <a href="/products/${item.id}"><h3> ${item.title}</h3></a>
                                        <p>${item.content}</p>
                                    </div>
                                </div>
                        `
                        }).join("")}
                    
                    </div>


        </section>
                <section class="contact">
                <h2>Contact us</h2>
                <form action="">
                    <div class="col">
                        <div class="row">
                            <label for="">Name</label>
                            <input type="text" placeholder="Enter your name...">
                        </div>
                        <div class="row">
                            <label for="">Subject</label>
                            <input type="text" placeholder="Enter subject...">
                        </div>
                    </div>
                    <div class="col">
                        <div class="row">
                            <label for="">Email Address</label>
                            <input type="text" placeholder="Your email address...">
                        </div>
                        <div class="row">
                            <label for="">Enquiry type</label>
                            <select name="" id="">
                                <option value="">Advertising</option>
                            </select>
                        </div>
                    </div>
                    <div>
                        <label for="">Messages</label>
                        <textarea name="" id="" cols="30" rows="10" placeholder="Enter your messages..."></textarea>
                    </div>
                    <button type="submit" class="btn-submit">Submit</button>
                </form>
            </section>
            
                <footer>
                    ${footer.render()}
                </footer>
            </div>
        `
    }
}

export default HomePage;