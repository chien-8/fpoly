import { getAll } from "../api/products";
import footer from "../component/footer";
import Header from "../component/header";
import stypes from "../stype/product.css" assert {type: 'css'}
document.adoptedStyleSheets[stypes];


const ProductPage = {
    async render() {
        const productList=(await getAll()).data;
        console.log(productList);
        return /* html */ `
        <div class="container">
        <header>
            ${Header.render()}
        </header>
        <main >
            <div id="category">
                <ul id="cate-list">
                    <li><a href="">breakfast</a></li>
                    <li><a href="">vegan</a></li>
                    <li><a href="">meat</a></li>
                    <li><a href="">dessert</a></li>
                    <li><a href="">lunch</a></li>
                    <li><a href="">chocolate</a></li>
                </ul>
            </div>
            
            <div id="list-product">
                
                ${productList.map((item)=>{
                return /*html*/`
                <div class="popular__item">
                    <div class="item">
                        <img src="${item.image}">
                        <a href="/products/${item.id}"><h3> ${item.title}</h3></a>
                        <p>${item.content}</p>
                    </div>
                </div>

                `
                }).join("")}
                
            
            </div>
             
        </main>
        <footer>
             ${footer.render()}
        </footer>
    </div>
        `
    }
}
export default ProductPage;