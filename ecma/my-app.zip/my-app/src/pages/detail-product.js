import { getOne } from "../api/products";
import Header from "../component/header";
import footer from "../component/footer";
import stypes from "../stype/detail.css" assert {type: 'css'};
document.adoptedStyleSheets[stypes];
const DetailProduct = {
    async render(id){
        const product = (await getOne(id)).data;
        console.log(product);
        // const product = productList.find((item)=>{
        //     return item.id == id;
        // })
        return /*html*/`
        <div class="conatiner">
            <header>
                ${Header.render()}
            </header>
            <div>
                <img src="${product.image}" alt="" />
                <h3>${product.title}</h3>
                <p>${product.content}</p>
            </div>

            <footer>
                ${footer.render()}
            </footer>
        </div>
            
        `
    }
}
export default DetailProduct;