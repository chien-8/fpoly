import { add } from "../api/products";
import sty from "../stype/add.css" assert{type:"css"}
document.adoptedStyleSheets[sty];

const AddNewProduct = {
    render() {
        return /*html*/`
            
            <main>
                
                <form action="" id="add-new" class="admin">
                    <h3>Add new product</h3>
                    <input type="text" placeholder="Product Name" id="title"/>
                    <div class="error"></div>
                    <input  type="text" placeholder="Product Image" id="image"/>
                    <div class="error"></div>
                    <textarea name="" id="content" cols="30" rows="10"></textarea>
                    <div class="error"></div>
                    <button>Add New Product</button>
                </form>
            </main>
            
        `
    },
    afterRender() {
        var fields = ["title", "image", "content"]
        document.querySelector("#add-new").addEventListener("submit", (e) => {
            e.preventDefault();
            var error = false;
            fields.forEach(function (item) {
                var field = document.querySelector("#" + item)
                if (field.value === "") {
                    showError(item, "trường dữ liệu bắt buộc")
                    error = true
                } else {
                    showError(item, "")
                }
            })
            if (!error) {
                const newProduct = {
                    title: document.querySelector("#title").value,
                    image: document.querySelector("#image").value,
                    content: document.querySelector("#content").value
                }
                console.log(newProduct);

                add(newProduct).then(function () {
                    location.assign("http://127.0.0.1:5173/admin/manage-product")
                });
            }

        })
    }
}

function showError(id, content) {
    var element = document.querySelector("#" + id)
    if (element.nextElementSibling) {
        element.nextElementSibling.innerHTML = content
    }
}
export default AddNewProduct