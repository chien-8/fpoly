import { getOne, remove } from "../api/products"
const deleteProduct = {
    async render(id) {
        const product = (await getOne(id)).data;
        console.log(product);
        remove(product).then(function (result) {
            location.assign("http://127.0.0.1:5173/admin/manage-product")
        });
        return ` `
    }

}


export default deleteProduct