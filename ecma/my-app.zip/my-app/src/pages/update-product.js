import { getOne, update } from "../api/products"
import sty from "../stype/add.css" assert{type:"css"}
document.adoptedStyleSheets[sty];
const UpdateProduct = {
    async render(id) {
        const product = (await getOne(id)).data;
        console.log(product);
        return /*html*/`
        <div class="container">
            <main>
                <form action="" id="update" class="admin">
                    <h3>Update product</h3>
                    <input  type="text" placeholder="Product Name" id="title" value="${product.title}"/>
                    <div class="error"></div>
                    <input type="text" placeholder="Product Image" id="image" value="${product.image}"/>
                    <div class="error"></div>
                    <textarea name="" id="content" cols="30" rows="10">${product.content}</textarea>
                    <div class="error"></div>
                    <button>Update Product</button>
                </form>
            </main>
        </div>
        `
    },
    afterRender(id) {
        var fields = ["title", "image", "content"]
        document.querySelector("#update").addEventListener("submit", (e) => {
            e.preventDefault();
            var error = false;
            fields.forEach(function (item) {
                var field = document.querySelector("#" + item)
                if (field.value === "") {
                    showError(item, "trường dữ liệu bắt buộc")
                    error = true
                } else {
                    showError(item, "")
                }
            })
            if (!error) {
                const postUpdate = {
                    id: id,
                    title: document.querySelector("#title").value,
                    content: document.querySelector("#content").value,
                    image: document.querySelector("#image").value
                }
                console.log(postUpdate)
                // console.log(postUpdate);
                update(postUpdate).then(function (result) {
                    location.assign("http://127.0.0.1:5173/admin/manage-product")

                });
            }



        })
    }
}

function showError(id, content) {
    var element = document.querySelector("#" + id)
    if (element.nextElementSibling) {
        element.nextElementSibling.innerHTML = content
    }
}
export default UpdateProduct