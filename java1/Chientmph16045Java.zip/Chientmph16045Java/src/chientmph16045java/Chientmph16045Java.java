
package chientmph16045java;

public class Chientmph16045Java {

    public static void main(String[] args) {
        QuanLyHoaQua ql=new QuanLyHoaQua();
        ql.menu();
    }
    
}
