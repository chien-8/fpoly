
package lap8.bai1;


public class bai4 {

    

    
    public static void main(String[] args) {
        
        System.out.printf("tong la: %.1f",Lap8Bai1.sum(3,5,6,7));
         System.out.printf("min la: %.1f",Lap8Bai1.min(1,2,3,4));
          System.out.printf("max la: %.1f",Lap8Bai1.sum(7,5,6,9));
           System.out.printf("chu la: %s",Lap8Bai1.toUppreFirstChar("Nguyen van an"));
        
    }
}
