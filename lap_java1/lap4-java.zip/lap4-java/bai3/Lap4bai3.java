
package lap4bai3;
public class Lap4bai3 {
    public static void main(String[] args) {
        SP_Bai3 sp1=new SP_Bai3("sp1",40,3);
        sp1.xuat();
        SP_Bai3 sp2=new SP_Bai3("sp2",800);
        sp2.xuat();
        
                

    }
    
}
