
package nhanvien_ass;

public class Main_Ass {
    public static void main(String[] args) {
        QuanLyNv_Ass ql =new QuanLyNv_Ass();
        ql.menu();
    }
    
}
