package lap7bai1;

public class Lap7bai1 {

    public static void main(String[] args) {
        ChuNhat cn = new ChuNhat();
        System.out.println("moi ban nhap thong tin hcn:");
        cn.nhap();
        cn.xuat();
        Vuong vu = new Vuong();
        vu.nhap();
        vu.xuat();
    }

}
