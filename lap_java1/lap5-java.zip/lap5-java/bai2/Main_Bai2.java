
package lap5bai2;


public class Main_Bai2 {
    public static void main(String[] args) {
        Lap5bai2 Ht = new Lap5bai2();
        Ht.menu();
    }
}
