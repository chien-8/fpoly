
package lap5bai1;
public class Lap5bai1 {
    public static void main(String[] args) {
        SanPham sp=new SanPham();
        sp.nhap();
        sp.hienThi();
        sp.tinhTong();
    }
}
