
package lap5_bai3;


public class MainChay {
    public static void main(String[] args) {
        QuanLy_SP ql=new QuanLy_SP();
        ql.menu();
    }
}
